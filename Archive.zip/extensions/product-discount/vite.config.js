// Prevents inheritance from parent Remix project
